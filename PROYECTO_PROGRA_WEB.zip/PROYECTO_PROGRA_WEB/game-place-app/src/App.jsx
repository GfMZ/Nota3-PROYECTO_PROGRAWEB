import React from 'react';
import Home from './pages/Home';
import './styles.css';

function App() {
  return <Home />;
}

export default App;

